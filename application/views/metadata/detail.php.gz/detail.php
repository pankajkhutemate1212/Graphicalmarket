<style>
@media only screen and (max-width: 736px){
					.col-xs-1, .col-sm-1, .col-md-1, .col-lg-1, .col-xs-2, .col-sm-2, .col-md-2, .col-lg-2, .col-xs-3, .col-sm-3, .col-md-3, .col-lg-3, .col-xs-4, .col-sm-4, .col-md-4, .col-lg-4, .col-xs-5, .col-sm-5, .col-md-5, .col-lg-5, .col-xs-6, .col-sm-6, .col-md-6, .col-lg-6, .col-xs-7, .col-sm-7, .col-md-7, .col-lg-7, .col-xs-8, .col-sm-8, .col-md-8, .col-lg-8, .col-xs-9, .col-sm-9, .col-md-9, .col-lg-9, .col-xs-10, .col-sm-10, .col-md-10, .col-lg-10, .col-xs-11, .col-sm-11, .col-md-11, .col-lg-11, .col-xs-12, .col-sm-12, .col-md-12, .col-lg-12{padding-left:0px;padding-right:0px;}
</style>
<?php
$no= substr($press['id'], -1);
switch ($no) {
	case 0:
        $img=1; break;
    case 1:
        $img=2; break;
    case 2:
        $img=3; break;
    case 3:
        $img=4; break;
    case 4:
        $img=5; break;
    case 5:
        $img=1; break;
    case 6:
        $img=2; break;
    case 7:
        $img=3; break;
    case 8:
        $img=4; break;
    case 9:
        $img=5; break;
    default:
        echo " ";
}
?>
<?php if($this->uri->segment(1)=='news'){$filename= 'assets/images/news/'.$press['url'].'.jpg';} 
elseif($this->uri->segment(1)=='industry'){$filename='assets/images/industry/'.$press['url'].'.jpg';}
elseif($this->uri->segment(1)=='technology'){$filename='assets/images/technology/'.$press['url'].'.jpg';}
else{$filename='assets/images/market/'.$press['url'].'.jpg';}

if($this->uri->segment(1)=='news'){$c='market-news-';} 
elseif($this->uri->segment(1)=='industry'){$c='industry-trends-';}
elseif($this->uri->segment(1)=='technology'){$c='technology-';}
else{$c='market-business-update-';}
$k= $c.''.$img.'.jpg'; 
?>

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "url": "<?php echo base_url(); ?>",
  "name": "ALGOSONLINE"
  
}
</script>

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage":"<?php echo current_url(); ?>",
  "headline": "<?php echo substr($press['name'], 0, 80); ?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php if(file_exists($filename)){echo base_url(); echo $filename;}else{echo base_url('assets/imgs');?>/<?php echo $k;}?>",
    "height": 800,
    "width": 800
  },
  "datePublished": "<?php $d = new DateTime($press['publish_date']);

$timestamp = $d->getTimestamp(); // Unix timestamp
$formatted_date2 = $d->format('Y-m-d');

echo $formatted_date2;

?>",
  "dateModified": "<?php $d = new DateTime($press['publish_date']);

$timestamp = $d->getTimestamp(); // Unix timestamp
$formatted_date1 = $d->format('Y-m-d');

echo $formatted_date1;

?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo $press['author']; ?>"
  },
   "publisher": {
    "@type": "Organization",
    "name": "ALGOSONLINE",
    "logo": {
      "@type": "ImageObject",
      "url": "<?php echo base_url(); ?>assets/images/algosonline-logo.png",
      "width": 600,
      "height": 60
    }
  },
  "description": "<?php $str=$press['full_desc'] ; echo strip_tags($str); ?>"
}
</script> 


<div class="technology-1">

	<div class="container">

       

		<div class="col-md-9 technology-left">

             <div class="breadcrumb">

    			<li><a href="<?php echo base_url('');?>">Home</a></li>

            <li><a href="<?php echo base_url();?><?php echo $this->uri->segment(1); ?>" style="text-transform: capitalize;"><?php echo $this->uri->segment(1); ?></a></li>

    			<li class="active"><?php echo $press['name']; ?></li>

            </div>

		 
            

			<div class="business">       

				<div class=" blog-grid2">

					<div class="blog-text">

					 <?php $d = new DateTime($press['publish_date']);

$timestamp = $d->getTimestamp(); // Unix timestamp
$formatted_date = $d->format('Y-m-d');

?>
           

           
						<h5><?php echo $press['name']; ?></h5>

                        <span>Date: <?php echo $formatted_date; ?></span> &nbsp; <span class="summary-date">Author: <a style="text-decoration:underline;" href="<?php echo base_url('author/'.str_replace(' ','-',strtolower($press['author'])));?>"><?php echo $press['author']; ?></a></span>
<?php  if (file_exists($filename)) {?>
   <img src="<?php echo base_url(); echo $filename;?>" class="img-responsive" alt="<?php echo $press['name']; ?>" style="margin-top:20px;">
<?php } else {?>
<img src="<?php echo base_url('assets/imgs/'.$k); ?>" class="img-responsive" alt="<?php echo $press['name']; ?>" style="margin-top:20px;">
<?php }?>
<span style="font-size: 13px">Source: pixabay</span>
  
							

                        

                        <p><?php echo $press['full_desc']; ?></p>				

					</div>

				</div>

				

			</div>

		</div>

		<!-- technology-right -->

		<div class="col-md-3 technology-right-1">

				<div class="blo-top">

					<div class="tech-btm">

                        <style>

                            .soci{

                                padding: 0;

                                float: none;

                            }

                            .soci ul > li{

                                display: inline-block;

                            }

                        </style>

					<div class="soci">

				<ul>
<?php if($this->uri->segment(1)=='news'){$f= 'news';} 
elseif($this->uri->segment(1)=='industry'){$f= 'industry';}
elseif($this->uri->segment(1)=='technology'){$f= 'technology';}
else{$f= 'market';}?>
					<li><a target="_blank" href="https://twitter.com/home?status=<?php echo base_url(''); echo $f;?>/<?php echo $press['url']; ?>" class="facebook-1"> </a></li>

					<li><a target="_blank" href="https://plus.google.com/share?url=<?php echo base_url(''); echo $f;?>/<?php echo $press['url']; ?>" class="facebook-1 twitter"> </a></li>

					<li><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url(''); echo $f;?>/<?php echo $press['url']; ?>" class="facebook-1 chrome"> </a></li>
					
					<li style="vertical-align: top;"><a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo base_url(''); echo $f;?>/<?php echo $press['url'];?>"><img height="42" width="42" src="<?php echo base_url(); ?>assets/linkedin.png" ></a></li>

					

				</ul>

			</div>

					</div>

				</div>

				

				<div class="blo-top1">

					<div class="tech-btm">

					<h4>Top stories of the week </h4>

						<div class="blog-grids">

                            

                            

                            

                            <?php if(!empty($ten_report))



		    {



              foreach($ten_report as $row){ ?>

                            

                            <div class="blog-grid-right" style="width:100%;

    margin-left: 0;text-align:justify;">

								

								<h5 style="font-size:14px;"><a href="<?php echo base_url();?><?php echo $this->uri->segment(1); ?>/<?php echo $row->url;?>"><?php echo str_replace("&","&amp;",$row->name); ?></a> </h5>

                                <p style="font-size:13px;"><?php echo substr($row->full_desc,0, 250);?>...</p>

                                <hr>

							</div><?php }} ?>

                            <div class="clearfix"> </div>

                            

						</div>

						</div>

				</div>

			

		</div>

		<div class="clearfix"></div>

		<!-- technology-right -->

	</div>

</div>